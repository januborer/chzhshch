/*
����:������ liyh@hainan.net
����:2007-8-16
����:ʵ��������Ҫ���ർ��
�÷�:ֱ��js����
����:��
�޸�:���Ͻ� chennj@hainan.net
�޸�����:2007-10-26
*/
if (navigator.userAgent.indexOf('Opera') >= 0)
{
	//opera���������ԭ���Ĵ���,
	document.write("<scr"+"ipt src='http://image.tianya.cn/guide/TopGuideJs/tianyaTopGuideJs100percentByOpera.js'></scr"+"ipt>");
}
else
{
	function getCookie_ByTopGuide(name){
	var dc = document.cookie;
	var prefix = name + "=";
	var begin = dc.indexOf("; " + prefix);
	if (begin == -1){
	begin = dc.indexOf(prefix);
	if (begin != 0) return null;
	}else{
	begin += 2;
	}

	var end = document.cookie.indexOf(";", begin);
	if (end == -1){
	end = dc.length;
	}
	return unescape(dc.substring(begin + prefix.length, end));
	}
	function getUniqueId_ByTopGuide(){
	var base = getCookie_ByTopGuide("base");

	if(base==null)
	return null;
	else{
	var temp = base.split('&')[1];				
	var uqid = temp.substring(temp.indexOf('=')+1,temp.length);

	return uqid;
	}
	}
	function getRegionId_ByTopGuide(){
	var base = getCookie_ByTopGuide("base");

	if(base==null)
	return null;
	else{
	var temp = base.split('&')[0];
	var dtid = temp.substring(temp.indexOf('=')+1,temp.length);

	return dtid;
	}
	}
	function getUserName_ByTopGuide(){
	var user = getCookie_ByTopGuide("user");

	if(user==null)
	return null;
	else{
	var temp = user.split('&')[0];
	var userName = temp.substring(temp.indexOf('=')+1,temp.length);

	return userName;
	}
	}
	function getUserId_ByTopGuide(){
	var user = getCookie_ByTopGuide("user");	

	if(user==null)
	return 0;
	else{
	var temp = user.split('&')[1];
	var userId = temp.substring(temp.indexOf('=')+1,temp.length);

	return userId;
	}
	}
	function getKey_ByTopGuide(){
	var temp = getCookie_ByTopGuide("temp");	

	if(temp==null)
	return 0;
	else{
	var temp1 = temp.split('&')[0];
	var key = temp1.substring(temp1.indexOf('=')+1,temp1.length);

	return key;
	}
	}

	function getCookie_TimeByTopGuide(){
	var temp = getCookie_ByTopGuide("temp");	

	if(temp==null)
	return 1000000000;
	else{
	var temp1 = temp.split('&')[2];
	var cookieTime = temp1.substring(temp1.indexOf('=')+1,temp1.length);

	return cookieTime;
	}
	}
	var key_ByTopGuide=getKey_ByTopGuide();
	var idwriter_ByTopGuide=getUserId_ByTopGuide();

	var aParams = document.location.search.substr(1).toLowerCase().split('&');
	var QueryLen=aParams.length;
	var QueryString="";
	var startFlag=true;
	var myHref="";
	//����aParams�а�����idwriter��key��������װ�����ѯ��
	for(var i=0;i<aParams.length;i++)
	{
		if (aParams[i].indexOf("idwriter")!=-1)
		{
			QueryLen=QueryLen-1;
			continue;
		}
		if(aParams[i].indexOf('key')!=-1)
		{
			QueryLen=QueryLen-1;
			continue;
		}
		if (startFlag==true)
		{
			QueryString=aParams[i];
			startFlag=false;
		}
		else
		{
			QueryString=QueryString+"&"+aParams[i];
		}
	}
	if (QueryString=="")
	{
		myHref=document.location.href.toLowerCase().split('?')[0];
	}
	else
	{
		myHref=document.location.href.toLowerCase().split('?')[0]+"?"+QueryString;
	}
	if (!(myHref.indexOf("content")>0 || myHref.indexOf("info.tianya.cn")>0))//content,infoҳ�治��Ҫ������ർ��,
	{
		myHref=encodeURIComponent(myHref);
		myHref="http://www.tianya.cn/index.htm?vitem="+myHref;
	}

	document.write('<style type="text/css">');
	document.write('<!-- ');
	document.write('#tianyaTopGuideLoginDiv {clear:both;width:350px;height:159px;background:white;z-index:102;position:absolute;align:left;}');
	document.write('#tianyaTopGuideDiv {background:#EFF7FF;-moz-opacity:0;opacity:0;filter:alpha(opacity=0);z-index:101;border:0;}');
	document.write('#tianyaTopGuideIframe {-moz-opacity:0;opacity:0;filter:alpha(opacity=0);z-index:100;border:0;}');
	document.write('#tianyatopguide_nav {margin-top:2px; font-size:12px; border-bottom:4px solid #E3E3E3; height:45px; }');
	document.write('#tianyatopguide_nav .tianyatopguidenavlogo{float:left;height:35px;width:95px}');
	document.write('#tianyatopguide_nav .tianyatopguidenavl{float:left;height:35px;padding-top:8px;text-align:left;color:#646464;line-height:18px;font-size:12px; }');
	document.write('#tianyatopguide_nav .tianyatopguidenavl a{ text-decoration:none;color:#777; }');
	document.write('#tianyatopguide_nav .tianyatopguidenavl a:hover{ color:#ff6600;text-decoration:none;}');
	document.write('#tianyatopguide_nav .tianyatopguidenavr{float:right;height:35px;text-align:right;color:#646464;line-height:18px;font-size:12px;padding-top:8px; }');
	document.write('#tianyatopguide_nav .tianyatopguidenavr a{ text-decoration:none;color:#777;font-size:12px; }');
	document.write('#tianyatopguide_nav .tianyatopguidenavr a:hover{ color:#ff6600;text-decoration:none;font-size:12px; }');
	document.write('.clear { clear:both}');
	document.write('#tianyatopguide_nav .tianyatopguidenavl ,#tianyatopguide_nav .tianyatopguidenavl a ,#tianyatopguide_nav .tianyatopguidenavl a:hover,#tianyatopguide_nav .tianyatopguidenavr ,#tianyatopguide_nav .tianyatopguidenavr a ,#tianyatopguide_nav .tianyatopguidenavr a:hover {font-size:12px;line-height:18px;font-family: ����;}');
	document.write('#tianyatopguideloginlayer .tianyatopguidelogtab {border:#AEC6DE 4px solid ; background:#ffffff; font-size:14px; text-align:left;padding:4px;}');
	document.write('#tianyatopguideloginlayer .tianyatopguidelogbar {background:#E1ECF7;color:#3E749B;margin-top:1px;text-align:center;height:25px;padding-top:4px;padding-left:4px;clear:both;}');
	document.write('#tianyatopguideloginlayer .tianyatopguidelogbar .tianyatopguidel { float:left;padding:2px;font-size:14px;font-weight: bold;padding-top:3px;text-align:center;}');
	document.write('#tianyatopguideloginlayer .tianyatopguidelogbar .tianyatopguider {float:right;width:20px;padding-top:5px;}');
	document.write('#tianyatopguideloginlayer .tianyatopguidecol{padding-left:50px;margin:6px;font-size: 14px;}');
	document.write(' .clear {clear:both}');
	document.write(' -->');
	document.write('</style>');
	
	document.write('<div class="clear"></div>');
	var LoginFun=new function()
	{
		this.loginDivState=false;
		this.Opacity=0;
		this.Div="";
		this.LoginDiv="";
		this.timer;
		this.maxOpacity=60;//alphaֵ
		this.delay=10;//�ӳ�Ч��ʱ��ms
		this.stepOpacity=10;//ÿ��Ч��alpha����ֵ
		this.Iframe;
		this.showTopLoginDiv=function(_e,tipStr)
		{			
			if(document.getElementById("tianyaTopGuideIframe")==null)
			{
				var iframe = document.createElement("IFRAME");
				iframe.id = "tianyaTopGuideIframe";
				iframe.style.position = "absolute";
				iframe.style.left = 0;
				iframe.style.top = 0;
				iframe.style.width = (document.body.scrollWidth>document.body.offsetWidth)?document.body.scrollWidth:document.body.offsetWidth;
				iframe.style.height = (document.body.scrollHeight>document.body.offsetHeight)?(document.body.scrollHeight+20):document.body.offsetHeight;
				this.Iframe = iframe;
				var div = document.createElement("DIV");
				div.id = "tianyaTopGuideDiv";
				div.style.position = "absolute";
				div.style.left = 0;
				div.style.top = 0;
				div.oncontextmenu = function()
				{
					return false;
				}
				div.onselectstart = function()
				{
					return false;
				}
				this.Div = div;
				var div2 = document.createElement("DIV");
				div2.id = "tianyaTopGuideLoginDiv";
				div2.style.position = "absolute";
				div2.style.top = (document.body.scrollTop)+parseInt(document.body.clientHeight)/2-100;
				div2.style.left = document.body.scrollLeft+parseInt(document.body.clientWidth)/2-200;		
				this.LoginDiv=div2;
				
				div2.oncontextmenu = function()
				{
					return false
				}

				document.body.appendChild(iframe);
				document.body.appendChild(div);
				document.body.appendChild(div2);

			}
			else
			{
				this.Div = document.getElementById("tianyaTopGuideDiv");
				this.LoginDiv=document.getElementById("tianyaTopGuideLoginDiv");
				this.Iframe = document.getElementById("tianyaTopGuideIframe");
				this.Iframe.style.display = "block";
				this.Div.style.display = "block";
				this.LoginDiv.style.display = "block";
				this.LoginDiv.innerHTML = tipStr;
			}
			this.Div.style.width=document.body.scrollWidth;
			this.Div.style.height=document.body.scrollHeight;
			this.LoginDiv.innerHTML = tipStr;
			this.timer=window.setInterval("LoginFun.showByStep()",this.delay);//�ڴ˲���ʹ��this.showByStep(),
			var l = document.body.scrollLeft;
			var t = document.body.scrollTop;
			document.body.style.overflow = "hidden";
			document.body.scrollLeft = l;
			document.body.scrollTop = t;
		};
		this.showByStep=function()
		{						
			if(this.Opacity == this.maxOpacity)
			{
				window.clearInterval(this.timer);
				return;
			}	

			this.Opacity=(this.Opacity + this.stepOpacity) > this.maxOpacity ? this.maxOpacity :this.Opacity + this.stepOpacity;
			this.Div.style.filter = "Alpha(Opacity= " + this.Opacity + ")";
			this.Div.style.opacity=parseInt(this.Opacity)/100;
		};
		this.hiddenTopLoginDiv=function()
		{
			this.loginDivState=false;
			document.body.style.overflow='auto';
			this.timer=window.setInterval("LoginFun.hiddenByStep()",this.delay);
		};
		this.hiddenByStep=function()
		{
			if(this.Opacity == 0)
			{
				window.clearInterval(this.timer);
				this.Iframe.style.display='none';
				this.Div.style.display='none';
				this.LoginDiv.style.display='none';
				return;
			}		
			this.Opacity = (this.Opacity - this.stepOpacity) < 0 ? 0: this.Opacity - this.stepOpacity;
			this.Div.style.filter = "Alpha(Opacity=" + this.Opacity + ")";
			this.Div.style.opacity = parseInt(this.Opacity)/100;
		};
		this.ForbidScrolling=function()
		{
			document.body.scrollTop=0;
		};
		this.Login=function(_e)
		{			
			this.showTopLoginDiv(_e,'<div id=\'tianyatopguideloginlayer\' style=\'display\'><form name=\'topguideloginform\' action=\'PostRecommendLogin_Submit.asp?PostID='+intPostID+'&BlogID='+intBlogID+'\' method=\'post\' target=_top><div class=\'tianyatopguidelogtab\'><div class=\'tianyatopguidelogbar\'><div class=\'tianyatopguidel\'>������¼</div><div class=\'tianyatopguider\'><a href=javascript:void(\'����رյ�¼...\'); height=\'12\' onclick=\'LoginFun.hiddenTopLoginDiv();\' style=\'cursor:pointer;size:14px\' title=\'����رյ�¼\'>X</a></div></div><br><div class=\'tianyatopguidecol\'>�û�����<input name=\'txtUserName\' type=\'text\' size=\'20\' /></div><div class=\'tianyatopguidecol\'> �ܡ��룺<input name=\'txtPassWord\' type=\'password\' size=\'20\' /><INPUT TYPE=\'hidden\' name=\'returnURL\' value=\''+myHref+'\'><INPUT TYPE=\'hidden\' value=\''+myHref+'\' name=\'fowardURL\'></div><div class=\'tianyatopguidecol\' style=\'text-align:center;padding-right:30px \'><input type=\'submit\' name=\'Submit\' value=\' ��¼ \' /> ��������,<a href=\'http:\/\/id.tianya.cn/user/register\' target=_blank>����ע��</a></div><br></div></form></div>');
			
		};
	}
	//window.onscroll = LoginFun.ForbidScrolling;
	
}