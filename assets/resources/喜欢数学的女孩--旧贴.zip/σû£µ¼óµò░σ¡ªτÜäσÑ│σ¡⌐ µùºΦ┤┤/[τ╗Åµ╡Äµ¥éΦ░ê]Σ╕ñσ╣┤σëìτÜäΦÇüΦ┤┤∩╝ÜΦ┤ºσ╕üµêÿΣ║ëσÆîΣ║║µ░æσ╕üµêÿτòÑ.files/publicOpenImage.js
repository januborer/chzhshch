function funCheckURL(obj)
{
	var strUrl=obj.src;
	var strId=obj.id;
	if(strId!="firstpostbottomad")//�����²���ͼƬ���������
	{
		if (strUrl.toLowerCase().indexOf("tianya.cn/photo") != -1)
		{
			var lastLength = strUrl.lastIndexOf("_");
			var fLength = strUrl.lastIndexOf("/");
			var strPhotoID = strUrl.substring(fLength+1,lastLength);		
			Url = 'http://pic.tianya.cn/myalbum/CheckURL.asp?idWriter='+idWriter+'&Key='+key+'&PhotoID='+strPhotoID;
			window.open(Url);
		}
		else
		{
			window.open('http://pic.tianya.cn/default.asp?idWriter='+idWriter+'&Key='+key+'');
		}
	}
}