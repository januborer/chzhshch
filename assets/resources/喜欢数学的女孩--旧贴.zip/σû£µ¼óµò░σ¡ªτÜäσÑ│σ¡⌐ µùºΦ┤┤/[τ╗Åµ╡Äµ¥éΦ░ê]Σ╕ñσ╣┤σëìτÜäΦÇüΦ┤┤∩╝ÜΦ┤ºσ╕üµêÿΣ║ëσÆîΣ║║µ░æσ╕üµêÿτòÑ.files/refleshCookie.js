var m35=300;//5����
var cookieTime=getCookieTempTime();
var cookieCstmTime=parseInt(getCookieCstmTime());
var Key=getKey();
var idWriter=getUserId();
var strWriter=getUserName();
var myCstTime=parseInt(new Date().getTime()/1000);
Key=(Key==null?0:Key);
idWriter=(idWriter==null?0:idWriter);
strWriter=(strWriter==null?"":strWriter);
cookieTime=parseInt(cookieTime);
var url="http://www.tianya.cn/user/refleshOnlineByCache.asp?t="+cookieTime+"&idwriter="+idWriter+"&key="+Key+"&strwriter="+strWriter+"&s="+Math.random()+"";	
if (cookieCstmTime+m35<myCstTime && Key>0)
{
	document.write("<scr"+"ipt src=\""+url+"\"><\/scr"+"ipt>");
}
var IsLoadRefleshCookieFile=true;