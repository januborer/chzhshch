var CreateReq=function()
{    
	var req = false;    
	try
	{        
		if(window.ActiveXObject)
		{            
			for(var i = 5; i; i--)
			{               
				try
				{                   
					if( i == 2 )
					{
						req = new ActiveXObject( "Microsoft.XMLHTTP" );                       
					}
					else
					{
						req = new ActiveXObject("Msxml2.XMLHTTP." + i + ".0");	
						req.setRequestHeader("Content-Type","text/xml");
						req.setRequestHeader("Content-Type","gb2312");  						
					}
				break;	
				}               
				catch(e)
				{   
					req = false;              
				}          
			}       
		}
		else if( window.XMLHttpRequest )
		{            
			req = new XMLHttpRequest();           
			if (req.overrideMimeType) 
			{                
				req.overrideMimeType('text/xml');            
			}       
		}   
	}
	catch(e)
	{        
		req = false;   
	}    
	return req;
}
var xmlhttp;
var UserOnlineCheck="";
var f=document.forms["FormResponse"];
var fstrWriter="";
var fstrPassword="";
function Myonreadystatechange()
{
	if(xmlhttp.readyState==4&&xmlhttp.status==200)
	{
		UserOnlineCheck=xmlhttp.responseText;
		CheckResponseForm();
	}
}
function CheckResponseForm()
{
	if(UserOnlineCheck!="1")
	{
		alert("���Ѿ�����,�������û���������!");
		idWriter=0;
		key=0;
		strWriter=null;
		DisplayLoginInfo();
		return;
	}
	SubmitResponseForm();
}
function CheckSubmit() 
{
	var  b=f.strContent.value
	if (b=="")
	{
		alert("���ݲ���Ϊ��!")
		return;
	}
	if(key<=0 || idWriter=="" || idWriter<=0 || key=="" || BonlineCookiesCheck==false)
	{
		fstrWriter=gID("strWriter").value;
		fstrPassword=gID("strPassword").value;
		if(fstrWriter=="" || fstrPassword=="")
		{
			alert("�������û���������!");
			return;
		}
	}
	var BcancelCookiesCheck=false;//��ʱȡ���ύǰ�����߼��,�ύ���������
	if(BcancelCookiesCheck==true)
	{
		xmlhttp=new CreateReq();
		xmlhttp.onreadystatechange=Myonreadystatechange;
		url="/new/includes/useronlinecheck.asp?idwriter="+idWriter+"&key="+key+"&s="+Math.random()+"";
		xmlhttp.open("GET",url,true);
		xmlhttp.send(null);
	}
	else
	{
		SubmitResponseForm();
	}
}
function ChangeSubmitButtonState()
{
	document.forms["FormResponse"].submit2.disabled=false;
}
function gID()
{
	return document.getElementById(arguments[0]);
}
function SubmitResponseForm()
{
	f.action='http://post.tianya.cn/new/Publicforum/content_submit.asp?idwriter='+idWriter+'&key='+key+'&flag=<%=vflag%>#Bottom';
	f.submit();
	f.submit2.disabled='true';
}
var PicList=new Array();
for(var i=0;i<5;i++)
{
	PicList[i]="";
}
PicList[0]=1;
var PicBody;
function init()
{
	PicBody=document.getElementById("PicBody");
}
window.onload=init;
function AddAImage()
{
	for(var i=1;i<PicList.length;i++)
	{
		if(PicList[i]=="")
		{
			tr=document.createElement("tr");
			tr.id="strAlbumPicTr"+i;
			td=document.createElement("td");
			td.id="strAlbumPicTd"+i;
			tr.appendChild(td);
			PicBody.appendChild(tr);
			document.getElementById("strAlbumPicTd"+i).innerHTML='<a href=javascript:DelAImage("'+i+'") title=���><img src=http://www1.tianya.cn/new/images/icon-.gif border=0></a>&nbsp;������<input type="text" name="PicDesc'+i+'" maxlength="100" class="input" size="10" onkeydown="if(event.keyCode==13){event.keyCode=0;return false}"> <input type="text" name="strAlbumPicURL'+i+'" id="strAlbumPicURL'+i+'" size="40" class="input" maxlength="255" onkeydown="if(event.keyCode==13){event.keyCode=0;return false}" value="http://">&nbsp;<input type=button onclick=openWindow("/new/techforum/Choice_TianyPhoto.asp?ArrPhoto='+i+'","600","330","imagelist"); value=ͼƬ��ȡ><BR>';
			PicList[i]=i+1;
			break;
		}
		if(i==PicList.length-1 && PicList[PicList.length-1]!="")
		{
			alert("�Բ������ֻ�ܼ�4�У�");
			return false;
		}
	}
}
function DelAImage(i)
{
	if(i=="")
	{
		document.getElementById("strAlbumPicURL").value="";
		return;
	}
	var tr=document.getElementById("strAlbumPicTr"+i);
	document.getElementById("strAlbumPicURL"+i).value="";
	tr.parentNode.removeChild(tr);
	PicList[i]="";
}
var idWriter=getUserId();
var strWriter=getUserName();
var key=getKey();
var cookieTime=getCookieTempTime();
if(isNaN(parseInt(key))){
	key=0;
}
if(isNaN(parseInt(idWriter))){
	idWriter=0;
}
var Key=key;
var idwriter=idWriter;
var BonlineCookiesCheck=true;
function DisplayLoginInfo()
{
	var DisplayLoginInfoDiv=document.getElementById("DisplayLoginInfoDiv");
	if(key<=0 || strWriter==null)
	{
		BonlineCookiesCheck=false;
		var _strWriter=document.createElement("input");
		var _password=document.createElement("input");
		_strWriter.type		=		"text";
		_strWriter.name		=		"strWriter";
		_strWriter.id		=		"strWriter";
		_strWriter.size		=		"14";
		_strWriter.className=		"input";	
		_strWriter.value	=		"";
		_strWriter.maxlength=		"20";
		_strWriter.setAttribute("onclick","ChangeSubmitButtonState();");//ֻ���firefox����,

		_password.type		=		"password";
		_password.name		=		"strPassword";
		_password.id		=		"strPassword";
		_password.size		=		"14";
		_password.className	=		"input";
		_password.value		=		"";
		_password.maxlength=		"20";
		_password.setAttribute("onclick","ChangeSubmitButtonState();");//ֻ���firefox����,
		
		var tText="";
		var tTextNode="";
		tText="�û���";
		DisplayLoginInfoDiv.innerHTML="<br><b>ע��</b>����ע���û�û�з�����Ϣ��Ȩ����<A HREF=http://www.tianya.cn target=_blank><font color=red>��½����>></font></A>&nbsp;&nbsp;<A HREF=http://www.tianya.cn/user/register/ target=_blank><font color=red>ע��>></font></A><br>";
		tTextNode=document.createTextNode(tText);
		DisplayLoginInfoDiv.appendChild(tTextNode);
		DisplayLoginInfoDiv.appendChild(_strWriter);
		tText="  ���";
		tTextNode=document.createTextNode(tText);
		DisplayLoginInfoDiv.appendChild(tTextNode);
		DisplayLoginInfoDiv.appendChild(_password);
	}
	else
	{
		DisplayLoginInfoDiv.innerHTML="<input type=hidden name=ckey id=ckey value="+key+"><input type=hidden name=cidWriter id=cidWriter value="+idWriter+">���ߣ�<font color=green>"+strWriter+"</font>";
	}	
}
if(IsShowLoginInfoDiv)
{
	DisplayLoginInfo();
	var saveblogJs=document.getElementById("saveblogJs");
	saveblogJs.src="../../../../new/js/saveBlog.js";//fangxu 2007.08.16
}
if(strWriter=="<%=rs_strWriter%>")
{
	var AddMyDigest=document.getElementById("AddMyDigest");
	AddMyDigest.innerHTML="<font color=red>��<\/font><A href='http:\/\/www.tianya.cn\/new\/tianyadigest\/UserCompose.asp?idWriter="+idWriter+"&Key="+Key+"&strItem=<%=strItem%>&idArticle=<%=idArticle%>' target=_blank>��������ļ�<\/a><br>";
}
String.prototype.ReWriteIdwriterKey=function()
{
	var _old,_new,_s;
	_s=this;

	_old = /idWriter=0/gi;
	_new = "idWriter="+idWriter+"";
	_s = _s.replace(_old, _new);

	_old = /Key=0/gi;
	_new = "Key="+Key+"";
	_s = _s.replace(_old, _new);

	_old = /<img /gi;
	_new = "<img onclick='javascript:funCheckURL(this);' alt='������´����в鿴��ͼƬ' style='cursor:pointer' ";
	_s = _s.replace(_old, _new)

	return(_s);
}
var pContentDiv=document.getElementById("pContentDiv"); 
pContentDiv.innerHTML=pContentDiv.innerHTML.ReWriteIdwriterKey();
document.forms["gform4"].idWriter.value=idwriter;
document.forms["gform4"].Key.value=key;
function openWindow(url,wide,high,name) 
{
url=url+"&idWriter="+idWriter+"&key="+key+"";
window.open(url,name,'width='+wide+',height='+high+',scrollbars=yes,resizable=yes,titlebar=no,status=no');
}